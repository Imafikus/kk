#ifndef __AST_HPP__
#define __AST_HPP__ 1

#include <string>
#include <iostream>
#include <map>
#include <vector>
#include <cstdlib>
using namespace std;

#include "vektor.hpp"

class SynTree {
public:
  virtual Vektor interpret() const = 0;
  virtual ~SynTree();
};

class ConstVector : public SynTree {
public:
  ConstVector(Vektor v)
    :_v(v)
  {}
  Vektor interpret() const;
private:
  Vektor _v;
};

class Variable : public SynTree {
public:
  Variable(string name)
    :_name(name)
  {}
  Vektor interpret() const;
private:
  string _name;
};

class Add : public SynTree {
public:
  Add(SynTree *l, SynTree *r)
    :_l(l), _r(r)
  {}
  Vektor interpret() const;
  ~Add();
private:
  Add(const Add&);
  Add& operator=(const Add&);
  SynTree *_l, *_r;
};

class Sub : public SynTree {
public:
  Sub(SynTree *l, SynTree *r)
    :_l(l), _r(r)
  {}
  Vektor interpret() const;
  ~Sub();
private:
  Sub(const Sub&);
  Sub& operator=(const Sub&);
  SynTree *_l, *_r;
};

class Mul : public SynTree {
public:
  Mul(double d, SynTree *r)
    :_d(d), _r(r)
  {}
  Vektor interpret() const;
  ~Mul();
private:
  Mul(const Mul&);
  Mul& operator=(const Mul&);
  double _d;
  SynTree *_r;
};

class Print : public SynTree {
public:
  Print(SynTree *r)
    :_r(r)
  {}
  Vektor interpret() const;
  ~Print();
private:
  Print(const Print&);
  Print& operator=(const Print&);
  SynTree *_r;
};

class Assign : public SynTree {
public:
  Assign(string name, SynTree *r)
    :_name(name), _r(r)
  {}
  Vektor interpret() const;
  ~Assign();
private:
  Assign(const Assign&);
  Assign& operator=(const Assign&);
  string _name;
  SynTree *_r;
};

class Declaration : public SynTree {
public:
  Declaration(vector < pair < string, SynTree* > > decls)
    :_decls(decls)
  {}
  Vektor interpret() const;
  ~Declaration();
private:
  Declaration(const Declaration&);
  Declaration& operator=(const Declaration&);
  vector < pair < string, SynTree* > > _decls;
};

class Block : public SynTree {
public:
  Block(vector < SynTree* > v)
    :_v(v)
  {}
  Vektor interpret() const;
  ~Block();
private:
  Block(const Block&);
  Block& operator=(const Block&);
  vector <SynTree*> _v;
};



#endif
