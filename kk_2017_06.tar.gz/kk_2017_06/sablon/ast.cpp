#include "ast.hpp"

SynTree::~SynTree() {

}

Vektor ConstVector::interpret() const {
  return _v;
}


extern map<string, Vektor> tablica_vektora;

Vektor Variable::interpret() const {
  map<string, Vektor>::iterator tmp = tablica_vektora.find(_name);
  if (tmp == tablica_vektora.end()) {
    cerr << "Vektor " + _name + " nije definisan" << endl;
    exit(EXIT_FAILURE);
  }
  return tmp->second;
}

Vektor Add::interpret() const {
  return _l->interpret() + _r->interpret();
}

Add::~Add() {
  delete _l;
  delete _r;
}

Vektor Sub::interpret() const {
  return _l->interpret() - _r->interpret();
}

Sub::~Sub() {
  delete _l;
  delete _r;
}

Vektor Mul::interpret() const {
  return _r->interpret() * _d;
}

Mul::~Mul() {
  delete _r;
}

Vektor Print::interpret() const {
  cout << _r->interpret() << endl;
  return Vektor();
}

Print::~Print() {
  delete _r;
}

Vektor Assign::interpret() const {
  map<string, Vektor>::iterator tmp = tablica_vektora.find(_name);
  if (tmp == tablica_vektora.end()) {
    cerr << "Vektor " + _name + " nije definisan" << endl;
    exit(EXIT_FAILURE);
  }  
  Vektor v = _r->interpret();
  tmp->second = v;
  return v;
}

Assign::~Assign() {
  delete _r;
}

Vektor Declaration::interpret() const {
  for (unsigned i = 0; i < _decls.size(); i++) {
    map<string, Vektor>::iterator tmp = tablica_vektora.find(_decls[i].first);
    if (tmp != tablica_vektora.end()) {
      cerr << "Vektor " + _decls[i].first + " je vec definisan" << endl;
      exit(EXIT_FAILURE);
    }  
    Vektor v = _decls[i].second->interpret();
    tablica_vektora[_decls[i].first] = v;
  }
  return Vektor();
}

Declaration::~Declaration() {
  for (unsigned i = 0; i < _decls.size(); i++)
    delete _decls[i].second;
}

Vektor Block::interpret() const {
  for (unsigned i = 0; i < _v.size(); i++)
    _v[i]->interpret();
  return Vektor();
}

Block::~Block() {
  for (unsigned i = 0; i < _v.size(); i++)
    delete _v[i];
}

