#include <iostream>
#include <string>

using namespace std;

#include "llvm/IR/IRBuilder.h"
#include "llvm/IR/Module.h"
#include "llvm/IR/Verifier.h"
#include "llvm/IR/LegacyPassManager.h"
#include "llvm/Transforms/Scalar.h"
#include "llvm/Support/TargetSelect.h"

using namespace llvm;

int main() {
  LLVMContext theContext;
  unique_ptr<Module> theModule = make_unique<Module>("my module", theContext);
  IRBuilder<> builder(theContext);
  cout << endl;

  // Tip i32 umesto tipa double
  Type::getDoubleTy(theContext);
  Value *x = ConstantFP::get(theContext, APFloat(20.0));
  x->dump();
  Type::getInt32Ty(theContext);
  Value *y = ConstantInt::get(theContext, APInt(32, 20));
  y->dump();
  cout << endl;
  Value *z = ConstantInt::get(theContext, APInt(32, 6));
  z->dump();
  cout << endl;

  // instrukcije za sabiranje, oduzimanje, mnozenje, deljenje,
  // ostatak pri deljenju, manje i vece nad celim brojevima
  builder.CreateAdd(y, z, "tmpadd")->dump();
  builder.CreateSub(y, z, "tmpadd")->dump();
  builder.CreateMul(y, z, "tmpadd")->dump();
  builder.CreateUDiv(y, z, "tmpadd")->dump();
  builder.CreateSRem(y, z, "tmpadd")->dump();
  builder.CreateICmpSGT(y, z, "tmpadd")->dump();
  builder.CreateICmpSLT(y, z, "tmpadd")->dump();

  return 0;
}

