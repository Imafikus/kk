#ifndef __CODEGEN_HPP__
#define __CODEGEN_HPP__ 1

#include "llvm/IR/IRBuilder.h"
#include "llvm/IR/Module.h"
#include "llvm/IR/Verifier.h"
#include "llvm/IR/LegacyPassManager.h"
#include "llvm/Transforms/Scalar.h"
#include "llvm/Support/TargetSelect.h"

using namespace std;
using namespace llvm;

/* trenutni modul */
extern unique_ptr<Module> theModule;
/* kontekst */
extern LLVMContext theContext;
/* mapa koja preslikava lokalne promenljive u njihove alokatore */
extern map<string, AllocaInst*> namedValues;
/* builder za pravljenje instrukcija */
extern IRBuilder<> builder;
/* optimizacija funkcija */
extern unique_ptr<legacy::FunctionPassManager> theFPM;

/* inicijalizacija modula i pass-manager-a */
void initializeModuleAndPassManager();

/* kreiranje alokatora promenljive */
AllocaInst* createEntryBlockAlloca(Function* TheFunction, const string& name);


extern Function* m;
extern Function* printd;

#endif

