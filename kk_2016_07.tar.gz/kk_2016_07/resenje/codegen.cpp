#include "codegen.hpp"

/* trenutni modul */
unique_ptr<Module> theModule;
/* kontekst */
LLVMContext theContext;
/* mapa koja preslikava lokalne promenljive u njihove alokatore */
map<string, AllocaInst*> namedValues;
/* builder za pravljenje instrukcija */
IRBuilder<> builder(theContext);
/* optimizacija funkcija */
unique_ptr<legacy::FunctionPassManager> theFPM;


void initializeModuleAndPassManager() {
  theModule = make_unique<Module>("my module", theContext);
  theFPM = make_unique<legacy::FunctionPassManager>(theModule.get());
  //theFPM->add(createInstructionCombiningPass());
  //theFPM->add(createReassociatePass());
  //theFPM->add(createGVNPass());
  //theFPM->add(createCFGSimplificationPass());
  theFPM->doInitialization();
}

AllocaInst* createEntryBlockAlloca(Function* theFunction, const string& name) {
  IRBuilder<> b(&theFunction->getEntryBlock(), theFunction->getEntryBlock().begin());
  return b.CreateAlloca(Type::getInt32Ty(theContext), 0, name.c_str());
}

/* eksterna fja print_int */
Function* printd = nullptr;

/* main fja */
Function* m = nullptr;

