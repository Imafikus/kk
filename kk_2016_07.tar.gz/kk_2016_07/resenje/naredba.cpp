#include "naredba.hpp"

#include <map>
#include <iostream>

using namespace std;

void IspisIzraza::izvrsi() const {
  cout << _i->vrednost() << endl;
}

IspisIzraza::~IspisIzraza() {
  delete _i;
}

IspisIzraza::IspisIzraza(const IspisIzraza &n) {
  _i = n._i->klon();
}

IspisIzraza& IspisIzraza::operator=(const IspisIzraza &n) {
  if (this != &n) {
    delete _i;
    _i = n._i->klon();
  }
  return *this;
}

void IspisIzraza::ispis(int d) const {
  for (int j = 0; j < d; j++)
    cout << "\t";
  cout << "ispisi(";
  _i->ispis();
  cout << ")";
}

extern map<string, int> tablica;

void Dodela::izvrsi() const {
  tablica[_l] = _i->vrednost();
}

Dodela::~Dodela() {
  delete _i;
}

Dodela::Dodela(const Dodela& n) {
  _i = n._i->klon();
  _l = n._l;
}

Dodela& Dodela::operator=(const Dodela& n) {
  if (this != &n) {
    delete _i;
    _i = n._i->klon();
    _l = n._l;
  }
  return *this;
}

void Dodela::ispis(int d) const {
  for (int j = 0; j < d; j++)
    cout << "\t";
  cout << _l << " := ";
  _i->ispis();
}

void Blok::izvrsi() const {
  for (auto n : _v)
    n->izvrsi();
}

Blok::~Blok() {
  for (auto n : _v)
    delete n;
}

void Blok::ispis(int d) const {
  for (int j = 0; j < d; j++)
    cout << "\t";
  cout << "pocetak" << endl;
  for (unsigned i = 0; i < _v.size(); i++) {
    _v[i]->ispis(d+1);
    if (i < _v.size() - 1)
      cout << ";";
    cout << endl;
  }
  for (int j = 0; j < d; j++)
    cout << "\t";
  cout << "kraj";
}

void AkoJeOnda::izvrsi() const {
  if (_i->vrednost())
    _n1->izvrsi();
}

AkoJeOnda::~AkoJeOnda() {
  delete _i;
  delete _n1;
}

void AkoJeOnda::ispis(int d) const {
  for (int j = 0; j < d; j++)
    cout << "\t";
  cout << "ako_je ";
  _i->ispis();
  cout << " onda:" << endl;
  _n1->ispis(d+1);
}

void AkoJeOndaInace::izvrsi() const {
  if (_i->vrednost())
    _n1->izvrsi();
  else
    _n2->izvrsi();
}

AkoJeOndaInace::~AkoJeOndaInace() {
  delete _i;
  delete _n1;
  delete _n2;
}

void AkoJeOndaInace::ispis(int d) const {
  for (int j = 0; j < d; j++)
    cout << "\t";
  cout << "ako_je ";
  _i->ispis();
  cout << " onda:" << endl;
  _n1->ispis(d+1);
  cout << endl;
  for (int j = 0; j < d; j++)
    cout << "\t";
  cout << "inace: " << endl;
  _n2->ispis(d+1);
}

void DokJe::izvrsi() const {
  while (_i->vrednost())
    _n1->izvrsi();
}

DokJe::~DokJe() {
  delete _i;
  delete _n1;
}

void DokJe::ispis(int d) const {
  for (int j = 0; j < d; j++)
    cout << "\t";
  cout << "dok_je ";
  _i->ispis();
  cout << " radi_sledece:" << endl;
  _n1->ispis(d+1);
}

/******************** codegen *************************/

Value* IspisIzraza::codegen() const {
  string name("print_int");

  /* Ako se prvi put koristi eksterna fja print_int */
  if (printd == nullptr) {
    /* Jedan int kao argument */
    vector<Type*> v(1, Type::getInt32Ty(theContext));
    /* fja vraca int */
    FunctionType* fp = FunctionType::get(Type::getInt32Ty(theContext), v, false);
    printd = Function::Create(fp, Function::ExternalLinkage, name, theModule.get());
  }

  /* Jedan argument fje print_int */
  vector<Value*> argV;
  argV.push_back(_i->codegen());
  if (!argV.back())
    return nullptr;

  /* Kreiranje poziva fje */
  builder.CreateCall(printd, argV, "calltmp");
  return ConstantInt::get(theContext, APInt(32, 0));
}


Value* Dodela::codegen() const {
  Value *r = _i->codegen();
  /* Ako promenljiva nije alocirana, alociramo je, jer promenljive
     ne moraju da budu deklarisane pre koriscenja */
  if (!namedValues.count(_l))
    namedValues[_l] = createEntryBlockAlloca(m, _l);
  AllocaInst* alloca = namedValues[_l];
  /* Cuvanje vrednosti */
  builder.CreateStore(r, alloca);
  return ConstantInt::get(theContext, APInt(32, 0));
}

Value* Blok::codegen() const {
  for (unsigned i = 0; i < _v.size() ; i++)
    _v[i]->codegen();
  return ConstantInt::get(theContext, APInt(32, 0));
}

Value* AkoJeOnda::codegen() const {
  Value* condV = _i->codegen();
  if (!condV)
    return nullptr;
  
  Function* theFunction = builder.GetInsertBlock()->getParent();

  BasicBlock *thenBB = BasicBlock::Create(theContext, "then", theFunction);
  BasicBlock *mergeBB = BasicBlock::Create(theContext, "ifcont");

  builder.CreateCondBr(condV, thenBB, mergeBB);

  builder.SetInsertPoint(thenBB);
  Value* thenV = _n1->codegen();
  if (!thenV)
    return nullptr;
  builder.CreateBr(mergeBB);
  thenBB = builder.GetInsertBlock();

  theFunction->getBasicBlockList().push_back(mergeBB);
  builder.SetInsertPoint(mergeBB);

  return ConstantInt::get(theContext, APInt(32, 0));
}

Value* AkoJeOndaInace::codegen() const {
  Value* condV = _i->codegen();
  if (!condV)
    return nullptr;
  
  Function* theFunction = builder.GetInsertBlock()->getParent();

  BasicBlock *thenBB = BasicBlock::Create(theContext, "then", theFunction);
  BasicBlock *elseBB = BasicBlock::Create(theContext, "else");
  BasicBlock *mergeBB = BasicBlock::Create(theContext, "ifcont");

  builder.CreateCondBr(condV, thenBB, elseBB);

  builder.SetInsertPoint(thenBB);
  Value* thenV = _n1->codegen();
  if (!thenV)
    return nullptr;
  builder.CreateBr(mergeBB);
  thenBB = builder.GetInsertBlock();

  theFunction->getBasicBlockList().push_back(elseBB);
  builder.SetInsertPoint(elseBB);
  Value* elseV = _n2->codegen();
  if (!elseV)
    return nullptr;
  builder.CreateBr(mergeBB);
  elseBB = builder.GetInsertBlock();

  theFunction->getBasicBlockList().push_back(mergeBB);
  builder.SetInsertPoint(mergeBB);

  return ConstantInt::get(theContext, APInt(32, 0));
}

Value* DokJe::codegen() const {
  Function* theFunction = builder.GetInsertBlock()->getParent();

  BasicBlock *loopBB = BasicBlock::Create(theContext, "loop", theFunction);
  builder.CreateBr(loopBB);

  builder.SetInsertPoint(loopBB);

  
  Value* stopV = _i->codegen();
  if (!stopV)
    return nullptr;

  BasicBlock *loopBB1 = BasicBlock::Create(theContext, "loop1", theFunction);
  BasicBlock *afterLoopBB = BasicBlock::Create(theContext, "afterloop", theFunction);
  builder.CreateCondBr(stopV, loopBB1, afterLoopBB);

  builder.SetInsertPoint(loopBB1);  
  if (!_n1->codegen())
    return nullptr;

  builder.CreateBr(loopBB);
  
  builder.SetInsertPoint(afterLoopBB);
  
  return ConstantInt::get(theContext, APInt(32, 0));
}
