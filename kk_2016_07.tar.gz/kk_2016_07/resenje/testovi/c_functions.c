#include <stdio.h>

int print_int(int x) {
  printf("%d\n", x);
  return 0;
}
