#include <iostream>
#include <string>

using namespace std;

#include "llvm/IR/IRBuilder.h"
#include "llvm/IR/Module.h"
#include "llvm/IR/Verifier.h"
#include "llvm/IR/LegacyPassManager.h"
#include "llvm/Transforms/Scalar.h"
#include "llvm/Support/TargetSelect.h"

using namespace llvm;

int main() {
  LLVMContext theContext;
  unique_ptr<Module> theModule = make_unique<Module>("my module", theContext);
  IRBuilder<> builder(theContext);
  cout << endl;

  // Tip i32 umesto tipa double
  Type::getDoubleTy(theContext);
  Value *x = ConstantFP::get(theContext, APFloat(20.0));
  x->dump();
  Type::getInt32Ty(theContext);
  Value *y = ConstantInt::get(theContext, APInt(32, 20));
  y->dump();
  cout << endl;
  Value *z = ConstantInt::get(theContext, APInt(32, 6));
  z->dump();
  cout << endl;

  // instrukcije za sabiranje, oduzimanje, mnozenje, deljenje
  // poredjenje na jednakost
  builder.CreateAdd(y, z, "tmpadd")->dump();
  builder.CreateSub(y, z, "tmpsub")->dump();
  builder.CreateMul(y, z, "tmpmul")->dump();
  builder.CreateUDiv(y, z, "tmpdiv")->dump();
  builder.CreateICmpEQ(y, z, "tmpcmp")->dump();
  cout << endl;

  // poziv funkcije bez povratne vrednost
  vector<Type*> v(1, Type::getInt32Ty(theContext));
  FunctionType* fp = FunctionType::get(Type::getVoidTy(theContext), v, false);
  Function *f = Function::Create(fp, Function::ExternalLinkage, "printi", theModule.get());
  vector<Value*> argV;
  argV.push_back(y);
  builder.CreateCall(f, argV)->dump();

  return 0;
}

