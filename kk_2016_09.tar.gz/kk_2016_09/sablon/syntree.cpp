#include "syntree.hpp"
#include "funct.hpp"

// Prilikom interpretacije poziva funkcije, koristi se registar svih
// definisanih funkcija kome se pristupa preko statickog metoda Call,
// klase Funct

int FunctCallNode::Operate(const vector<int>& v)
{
  return Funct::Call(_name, v);
}

/* trenutni modul */
unique_ptr<Module> theModule;
/* kontekst */
LLVMContext theContext;
/* mapa koja preslikava lokalne promenljive u njihove alokatore */
map<string, AllocaInst*> namedValues;
/* builder za pravljenje instrukcija */
IRBuilder<> builder(theContext);
/* optimizacija funkcija */
unique_ptr<legacy::FunctionPassManager> theFPM;

Value* ConstantNode::Codegen() const
{
  //TODO
  return nullptr;
}

Value* VariableNode::Codegen() const
{
  //TODO
  return nullptr;
}

Value* PlusNode::Codegen() const
{
  //TODO
  return nullptr;
}

Value* TimesNode::Codegen() const
{
  //TODO
  return nullptr;
}

Value* DivideNode::Codegen() const
{
  //TODO
  return nullptr;
}

Value* MinusNode::Codegen() const
{
  //TODO
  return nullptr;
}

Value* EqNode::Codegen() const
{
  //TODO
  return nullptr;
}


Value* QuestionNode::Codegen() const
{
  //TODO
  return nullptr;
}

Value* AssignmentNode::Codegen() const
{
  //TODO
  return nullptr;
}

Value* FunctCallNode::Codegen() const
{
  //TODO
  return nullptr;
}


Value* PrintNode::Codegen() const
{
  //TODO
  return nullptr;
}

Value* SequenceNode::Codegen() const
{
  //TODO
  return nullptr;
}

void initializeModuleAndPassManager() {
  //TODO
}

AllocaInst* createEntryBlockAlloca(Function* theFunction, const string& name) {
  //TODO
}

Function* getFunction(string s) {
  //TODO
  return nullptr;
}
