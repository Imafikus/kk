#ifndef __FUNCTION_H__
#define __FUNCTION_H__

#include <vector>
#include <string>
#include <map>
using namespace std;

#include "syntree.hpp"


// Klasa kojom se predstavlja funkcija programskog jezika
// U okviru ove klase, napravljen je i registar kreiranih funkcija koji 
// omogucava da se definisanoj funkciji pristupi na osnovu imena
class Funct
{
public:
  // Konstruktor na osnovu imena, argumenata, imena rezultujuce promenljive i sintaksnog stabla 
  // koje predstavlja kod same funkcije
  // Prilikom konstrukcije, funkcija se upisuje u registar
  Funct(const string& name, const vector<string>& args, const string result, SynTreeNode* code)
    : _name(name), _args(args), _result(result), _code(code)
  {
    map<string, Funct*>::iterator i = _functions.find(name);
    if (i!=_functions.end())
      throw "Funct redefinition";
    
    // Upis funkcije u registar
    _functions[name] = this;
    
  }

  // Destruktor
  ~Funct();
  
  // Metod kojim se vrsi poziv funkcije sa datim imenom za date 
  // vrednosti argumenata
  static int Call(const string& name, const vector<int>& values)
  {
    // Pronalazimo odgovarajucu funkciju u registru
    Funct* f = GetFunct(name);
    // Proveravamo da li funkcija postoji
    if (f == 0)
      throw "Undefined function called";
    // Pozivamo funkciju
    return f->Call(values);
  }

  // Staticki metod koji uklanja sve funkcije iz registra
  static void DeleteFuncts()
  {	map<string, Funct*>::iterator i;
    for (i = _functions.begin(); i!=_functions.end(); i++)
      delete i->second;
  }

  Function* Codegen() const;

  // Staticki metod kojim se iz registra funkcija pronalazi 
  // funkcija sa datim imenom
  static Funct* GetFunct(const std::string& name)
  {	
    map<string, Funct*>::iterator i = _functions.find(name);
    return i==_functions.end() ? 0 : i->second;	
  }

  bool HasReturn() const {
    return _result != "";
  }

private:
  // Kod koji vrsi poziv ove funkcije sa datim vrednostima argumenata
  int Call(const vector<int>& values);
    
  // Ime funkcije
  string _name;
  
  // Imena ulaznih promenljivih funkcije
  vector<string> _args;
  
  // Ime rezultujuce promenljive
  string _result;
  
  // Sintaksno stablo za predstavljanje koda funkcije
  SynTreeNode* _code;
  
  // Globalni registar funkcija
  static map<string, Funct*>  _functions;
};

#endif
