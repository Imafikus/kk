#include <stdio.h>

int printi(int x) {
  printf("%d\n", x);
  return 0;
}

