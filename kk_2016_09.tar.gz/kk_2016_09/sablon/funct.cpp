#include "funct.hpp"
#include "syntree.hpp"

//Destruktor 
Funct::~Funct()
{
  delete _code;
}

// Registar funkcija
map<string, Funct*> Funct::_functions;

// Poziv funkcije za date vrednosti argumenata
int Funct::Call(const vector<int>& values)
{
  // Proveravamo korektnost broja argumenata
  if (values.size() != _args.size())
    throw "Wrong number of arguments in function call";
  
  // Formalnim argumentima dodeljujemo lokalne promenljive
  map<string, int> variables;
  for (size_t i = 0; i<values.size(); i++)
    variables[_args[i]] = values[i];
  
  // Vrsimo interpretaciju koda
  _code->Interpret(variables);
  
  // Rezultat se nalazi u promenljivoj sa imenom _result
  return variables[_result];
}

Function* Funct::Codegen() const
{
  //TODO
  return nullptr;
}
