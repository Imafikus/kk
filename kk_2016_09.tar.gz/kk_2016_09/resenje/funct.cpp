#include "funct.hpp"
#include "syntree.hpp"

//Destruktor 
Funct::~Funct()
{
  delete _code;
}

// Registar funkcija
map<string, Funct*> Funct::_functions;

// Poziv funkcije za date vrednosti argumenata
int Funct::Call(const vector<int>& values)
{
  // Proveravamo korektnost broja argumenata
  if (values.size() != _args.size())
    throw "Wrong number of arguments in function call";
  
  // Formalnim argumentima dodeljujemo lokalne promenljive
  map<string, int> variables;
  for (size_t i = 0; i<values.size(); i++)
    variables[_args[i]] = values[i];
  
  // Vrsimo interpretaciju koda
  _code->Interpret(variables);
  
  // Rezultat se nalazi u promenljivoj sa imenom _result
  return variables[_result];
}

Function* Funct::Codegen() const
{
  vector<Type*> v(_args.size(), Type::getInt32Ty(theContext));
  FunctionType* fp = nullptr;
  if (HasReturn())
    fp = FunctionType::get(Type::getInt32Ty(theContext), v, false);
  else
    fp = FunctionType::get(Type::getVoidTy(theContext), v, false);
  Function* theFunction = Function::Create(fp, Function::ExternalLinkage, _name, theModule.get());
  int j = 0;
  for (auto &a : theFunction->args())
    a.setName(_args[j++]);
  
  BasicBlock *bb = BasicBlock::Create(theContext, "entry", theFunction);
  builder.SetInsertPoint(bb);
  namedValues.clear();
  for (auto &a: theFunction->args()) {
    AllocaInst* alloca = createEntryBlockAlloca(theFunction, a.getName());
    namedValues[a.getName()] = alloca;
    builder.CreateStore(&a, alloca);
  }
  if (_code->Codegen()) {
    if (HasReturn()) {
      AllocaInst *v1 = namedValues[_result];
      if (!v1) {
	cerr << "Nepostojeca promenljiva " << _name << endl;
	return nullptr;
      }
      Value* tmp = builder.CreateLoad(v1);
      builder.CreateRet(tmp);
    }
    else {
      builder.CreateRetVoid();
    }
    verifyFunction(*theFunction);
    theFPM->run(*theFunction);
    return theFunction;
  }
  else {
    theFunction->eraseFromParent();
    return nullptr;
  }
}
