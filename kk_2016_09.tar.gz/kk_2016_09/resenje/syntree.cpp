#include "syntree.hpp"
#include "funct.hpp"

// Prilikom interpretacije poziva funkcije, koristi se registar svih
// definisanih funkcija kome se pristupa preko statickog metoda Call,
// klase Funct

int FunctCallNode::Operate(const vector<int>& v)
{
  return Funct::Call(_name, v);
}

/* trenutni modul */
unique_ptr<Module> theModule;
/* kontekst */
LLVMContext theContext;
/* mapa koja preslikava lokalne promenljive u njihove alokatore */
map<string, AllocaInst*> namedValues;
/* builder za pravljenje instrukcija */
IRBuilder<> builder(theContext);
/* optimizacija funkcija */
unique_ptr<legacy::FunctionPassManager> theFPM;

Value* ConstantNode::Codegen() const
{
  return ConstantInt::get(theContext, APInt(32, _value));
}

Value* VariableNode::Codegen() const
{
  AllocaInst *v = namedValues[_name];
  if (!v) {
    cerr << "Nepostojeca promenljiva " << _name << endl;
    return nullptr;
  }
  return builder.CreateLoad(v);
}

Value* PlusNode::Codegen() const
{
  Value *l = _operands[0]->Codegen();
  Value *r = _operands[1]->Codegen();
  if (!l || !r)
    return nullptr;
  return builder.CreateAdd(l, r, "tmpadd");
}

Value* TimesNode::Codegen() const
{
  Value *l = _operands[0]->Codegen();
  Value *r = _operands[1]->Codegen();
  if (!l || !r)
    return nullptr;
  return builder.CreateMul(l, r, "tmpmul");
}

Value* DivideNode::Codegen() const
{
  Value *l = _operands[0]->Codegen();
  Value *r = _operands[1]->Codegen();
  if (!l || !r)
    return nullptr;
  return builder.CreateUDiv(l, r, "tmpdiv");
}

Value* MinusNode::Codegen() const
{
  Value *l = _operands[0]->Codegen();
  Value *r = _operands[1]->Codegen();
  if (!l || !r)
    return nullptr;
  return builder.CreateSub(l, r, "tmpsub");
}

Value* EqNode::Codegen() const
{
  Value *l = _operands[0]->Codegen();
  Value *r = _operands[1]->Codegen();
  if (!l || !r)
    return nullptr;
  return builder.CreateICmpEQ(l, r, "tmpcmp");
}


Value* QuestionNode::Codegen() const
{
  Value *cond = _operands[0]->Codegen();
  
  Function* theFunction = builder.GetInsertBlock()->getParent();
  
  BasicBlock *thenBB = BasicBlock::Create(theContext, "then", theFunction);
  BasicBlock *elseBB = BasicBlock::Create(theContext, "else");
  BasicBlock *mergeBB = BasicBlock::Create(theContext, "ifcont");


  builder.CreateCondBr(cond, thenBB, elseBB);

  builder.SetInsertPoint(thenBB);
  Value* thenV = _operands[1]->Codegen();
  if (!thenV)
    return nullptr;
  builder.CreateBr(mergeBB);
  thenBB = builder.GetInsertBlock();

  theFunction->getBasicBlockList().push_back(elseBB);
  builder.SetInsertPoint(elseBB);
  Value* elseV = _operands[2]->Codegen();
  if (!elseV)
    return nullptr;
  builder.CreateBr(mergeBB);
  elseBB = builder.GetInsertBlock();

  theFunction->getBasicBlockList().push_back(mergeBB);
  builder.SetInsertPoint(mergeBB);

  PHINode *pn = builder.CreatePHI(Type::getInt32Ty(theContext), 2, "iftmp");
  pn->addIncoming(thenV, thenBB);
  pn->addIncoming(elseV, elseBB);
  return pn;		
}

Value* AssignmentNode::Codegen() const
{
  Value *r = _expression->Codegen();

  Function* theFunction = builder.GetInsertBlock()->getParent();
  if (!namedValues.count(_var_name))
    namedValues[_var_name] = createEntryBlockAlloca(theFunction, _var_name);
  AllocaInst* alloca = namedValues[_var_name];
  return builder.CreateStore(r, alloca);
}

Value* FunctCallNode::Codegen() const
{
  Function *f = getFunction(_name);
  if (!f) {
    cerr << "Funkcija " << _name << " nije definisana" << endl;
    return nullptr;
  }
  if (f->arg_size() != _operands.size()) {
    cerr << "Poziv fje " << _name << "nema " << f->arg_size() << "argumenata" << endl;
    return nullptr;
  }
  vector<Value*> argV;
  for (auto e : _operands) {
    argV.push_back(e->Codegen());
    if (!argV.back())
      return nullptr;
  }

  if (Funct::GetFunct(_name)->HasReturn())
    return builder.CreateCall(f, argV, "calltmp");
  else
    return builder.CreateCall(f, argV);
}


Value* PrintNode::Codegen() const
{
  Function *f = getFunction("printi");
  if (!f) {
    cerr << "Funkcija print nije definisana" << endl;
    return nullptr;
  }

  vector<Value*> argV;
  argV.push_back(_expression->Codegen());
  if (!argV.back())
    return nullptr;

  return builder.CreateCall(f, argV);
}

Value* SequenceNode::Codegen() const
{
  _operands[0]->Codegen();
  _operands[1]->Codegen();
  return ConstantInt::get(theContext, APInt(32, 0));
}

void initializeModuleAndPassManager() {
  theModule = make_unique<Module>("my module", theContext);
  theFPM = make_unique<legacy::FunctionPassManager>(theModule.get());
  theFPM->add(createInstructionCombiningPass());
  theFPM->add(createReassociatePass());
  theFPM->add(createGVNPass());
  theFPM->add(createCFGSimplificationPass());
  theFPM->doInitialization();

  vector<Type*> v(1, Type::getInt32Ty(theContext));
  FunctionType* fp = FunctionType::get(Type::getVoidTy(theContext), v, false);
  Function::Create(fp, Function::ExternalLinkage, "printi", theModule.get());
}

AllocaInst* createEntryBlockAlloca(Function* theFunction, const string& name) {
  IRBuilder<> b(&theFunction->getEntryBlock(), theFunction->getEntryBlock().begin());
  return b.CreateAlloca(Type::getInt32Ty(theContext), 0, name.c_str());
}

Function* getFunction(string s) {
  Function *f = theModule->getFunction(s);
  if (f)
    return f;
  auto i = Funct::GetFunct(s);
  if (i != nullptr)
    return i->Codegen();
  return nullptr;
}
