#include <stdio.h>

double putchard(double x) {
  return putchar((int)x);
}

double printd(double x) {
  printf("%g\n", x);
  return 0;
}
