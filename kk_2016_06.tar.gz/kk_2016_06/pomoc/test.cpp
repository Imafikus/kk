#include <iostream>
#include <string>

using namespace std;

#include "llvm/IR/IRBuilder.h"
#include "llvm/IR/Module.h"
#include "llvm/IR/Verifier.h"
#include "llvm/IR/LegacyPassManager.h"
#include "llvm/Transforms/Scalar.h"
#include "llvm/Support/TargetSelect.h"

using namespace llvm;

int main() {
  LLVMContext theContext;
  unique_ptr<Module> theModule = make_unique<Module>("my module", theContext);
  IRBuilder<> builder(theContext);
  cout << endl;

  /* ------ deo pod b --------- */

  // Tip i32 umesto tipa double
  Type::getDoubleTy(theContext);
  Value *x = ConstantFP::get(theContext, APFloat(20.0));
  x->dump();
  Type::getInt32Ty(theContext);
  Value *y = ConstantInt::get(theContext, APInt(32, 20));
  y->dump();
  cout << endl;

  /* ------ deo pod b --------- */
  
  // Ime globalne promenljive
  string name("glprom");
  // Dodavanje globalne promenljive modulu
  theModule->getOrInsertGlobal(name, Type::getDoubleTy(theContext));
  // Globalna promenljiva
  GlobalVariable* gVar = theModule->getNamedGlobal(name);
  // Inicijalizacija globalne promenljive
  gVar->setInitializer(ConstantFP::get(theContext, APFloat(123.4)));
  // LLVM kod
  gVar->dump();
  
  // Kod citanja globalne promenljive ne treba name AllocaInst* za
  // razliku od lokalnih promenljivih, vec ovde imamo GlobalVariable*
  // Obe klase nasledjuju baznu klasu Value
  builder.CreateLoad(gVar)->dump();

  // Upisivanje globalne promenljive
  Value *startV = ConstantFP::get(theContext, APFloat(22.2));
  builder.CreateStore(startV, gVar)->dump();
  cout << endl;
    
  return 0;
}

